package com.example.athenaapp.domain

data class Query(val query: String, val engineType: String)