package com.example.athenaapp.configuration

import com.example.athenaapp.adapter.out.persistence.AthenaQueryExecutor
import com.example.athenaapp.adapter.out.persistence.QueryAdapter
import com.example.athenaapp.adapter.out.persistence.AthenaQueryStatusUpdater
import com.example.athenaapp.application.QueryService
import com.example.athenaapp.application.port.`in`.QueryUseCase
import io.ktor.server.application.* 

class AppConfig(private val application: Application) {

    val athenaQueryExecutor: AthenaQueryExecutor by lazy {
        AthenaQueryExecutor(application.environment.config)
    }

    val queryAdapter: QueryAdapter by lazy {
        QueryAdapter(mapOf("athena" to athenaQueryExecutor))
    }

    val athenaQueryStatusUpdater: AthenaQueryStatusUpdater by lazy {
        AthenaQueryStatusUpdater(application.environment.config)
    }

    val queryUseCase: QueryUseCase by lazy {
        QueryService(queryAdapter, athenaQueryStatusUpdater)
    }
}