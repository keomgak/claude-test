package com.example.athenaapp.application.port.`in`

import com.example.athenaapp.domain.Query

interface QueryUseCase {
    fun executeQuery(query: Query): String
}
