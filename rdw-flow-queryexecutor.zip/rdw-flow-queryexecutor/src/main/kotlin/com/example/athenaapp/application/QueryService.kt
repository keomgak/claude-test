package com.example.athenaapp.application

import com.example.athenaapp.application.port.`in`.QueryUseCase
import com.example.athenaapp.application.port.out.QueryExecutorPort
import com.example.athenaapp.application.port.out.QueryStatusSchedulerPort
import com.example.athenaapp.domain.Query

class QueryService(
    private val queryExecutorPort: QueryExecutorPort,
    private val queryStatusSchedulerPort: QueryStatusSchedulerPort
) : QueryUseCase {

    override fun executeQuery(query: Query): String {
        val queryExecutionId = queryExecutorPort.executeQuery(query)
        queryStatusUpdaterPort.scheduleStatusUpdate(queryExecutionId)
        return queryExecutionId
    }
}