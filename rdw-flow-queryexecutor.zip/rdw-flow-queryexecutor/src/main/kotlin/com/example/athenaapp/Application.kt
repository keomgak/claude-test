package com.example.athenaapp

import com.example.athenaapp.adapter.`in`.web.configureQueryController
import com.example.athenaapp.configuration.AppConfig
import com.example.athenaapp.configuration.configureSerialization
import io.ktor.server.application.* 
import io.ktor.server.engine.* 
import io.ktor.server.netty.* 

fun main(args: Array<String>): Unit = EngineMain.main(args)

fun Application.module() {
    val appConfig = AppConfig(this)

    configureSerialization()
    configureQueryController(appConfig.queryUseCase)

    environment.monitor.subscribe(ApplicationStopping) {
        appConfig.athenaQueryStatusUpdater.stop()
    }
}
