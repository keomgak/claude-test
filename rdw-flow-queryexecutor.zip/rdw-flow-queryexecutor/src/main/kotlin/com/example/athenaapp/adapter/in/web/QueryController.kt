package com.example.athenaapp.adapter.`in`.web

import com.example.athenaapp.application.port.`in`.QueryUseCase
import com.example.athenaapp.domain.Query
import io.ktor.server.application.* 
import io.ktor.server.request.* 
import io.ktor.server.response.* 
import io.ktor.server.routing.* 
import kotlinx.serialization.Serializable

fun Application.configureQueryController(queryUseCase: QueryUseCase) {
    routing {
        post("/query") {
            val request = call.receive<QueryRequest>()
            val queryExecutionId = queryUseCase.executeQuery(Query(request.query, request.engineType))
            call.respond(QueryResponse(queryExecutionId))
        }
    }
}

@Serializable
data class QueryRequest(val query: String, val engineType: String)

@Serializable
data class QueryResponse(val queryExecutionId: String)