package com.kakaobank.rdw.flow.queryexecutor.model

import kotlinx.serialization.Serializable

@Serializable
data class QueryStatusRequest(val queryId: String, val engineType: String)