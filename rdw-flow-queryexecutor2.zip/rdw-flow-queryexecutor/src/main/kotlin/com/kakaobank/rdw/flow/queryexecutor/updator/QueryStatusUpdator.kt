package com.kakaobank.rdw.flow.queryexecutor.updator

import com.kakaobank.rdw.flow.queryexecutor.engine.QueryEngineFactory
import kotlinx.coroutines.*
import software.amazon.awssdk.services.athena.model.QueryExecutionState

class QueryStatusUpdator(private val queryEngineFactory: QueryEngineFactory) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun trackQueryStatus(queryExecutionId: String, engineType: String) {
        scope.launch {
            var isDone = false
            while (!isDone) {
                try {
                    val engine = queryEngineFactory.getEngine(engineType)
                    val status: QueryExecutionState = engine.getQueryStatus(queryExecutionId)
                    println("Checking status for query ID: $queryExecutionId -> $status")

                    when (status.toString()) {
                        QueryExecutionState.SUCCEEDED.toString() -> {
                            println("Query $queryExecutionId succeeded.")
                            // Optionally, you can fetch and process results here
                            // val result = athenaRepository.getQueryResults(queryExecutionId)
                            // println("Results for $queryExecutionId: $result")
                            isDone = true
                        }
                        QueryExecutionState.FAILED.toString(),
                        QueryExecutionState.CANCELLED.toString() -> {
                            println("Query $queryExecutionId failed or was cancelled. Status: $status")
                            isDone = true
                        }
                        else -> {
                            // Still RUNNING or QUEUED, wait for the next poll
                            delay(60_000) // 1 minute
                        }
                    }
                } catch (e: Exception) {
                    println("Error checking status for query ID: $queryExecutionId. Error: ${e.message}")
                    isDone = true // Stop polling on error
                }
            }
        }
    }
}