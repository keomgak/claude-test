package com.kakaobank.rdw.flow.queryexecutor.plugins

import com.kakaobank.rdw.flow.queryexecutor.di.AppModule
import com.kakaobank.rdw.flow.queryexecutor.model.QueryCancelRequest
import com.kakaobank.rdw.flow.queryexecutor.model.QueryCancelResponse
import com.kakaobank.rdw.flow.queryexecutor.model.QueryRequest
import com.kakaobank.rdw.flow.queryexecutor.model.QueryResponse
import com.kakaobank.rdw.flow.queryexecutor.model.QueryStatusRequest
import com.kakaobank.rdw.flow.queryexecutor.model.QueryStatusResponse
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Application.configureRouting() {
    val queryService = AppModule.provideQueryService()

    routing {
        post("/query") {
            val request = call.receive<QueryRequest>()
            val queryExecutionId = queryService.startQuery(request.query, request.engineType)
            call.respond(QueryResponse(queryExecutionId))
        }

        post("/query/status") {
            val request = call.receive<QueryStatusRequest>()
            val status = queryService.getQueryStatus(request.queryId, request.engineType)
            call.respond(QueryStatusResponse(request.queryId, status.toString()))
        }

        post("/query/cancel") {
            val request = call.receive<QueryCancelRequest>()
            val success = queryService.cancelQuery(request.queryId, request.engineType)
            call.respond(QueryCancelResponse(success))
        }
    }
}