package com.kakaobank.rdw.flow.queryexecutor.engine

import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.athena.AthenaClient
import software.amazon.awssdk.services.athena.model.*

class AthenaQueryEngine(credentialsProvider: AwsCredentialsProvider) : QueryEngine {

    private val athenaClient: AthenaClient = AthenaClient.builder()
        .region(Region.AP_NORTHEAST_2) // AWS 리전 설정
        .credentialsProvider(credentialsProvider)
        .build()

    override fun startQuery(query: String): String {
        val startQueryExecutionRequest = StartQueryExecutionRequest.builder()
            .queryString(query)
            .queryExecutionContext {
                it.database("your_database_name") // Athena 데이터베이스 이름으로 변경
            }
            .resultConfiguration {
                it.outputLocation("s3://your-s3-bucket/query-results/") // S3 버킷 경로로 변경
            }
            .build()

        val response = athenaClient.startQueryExecution(startQueryExecutionRequest)
        return response.queryExecutionId()
    }

    override fun getQueryStatus(queryExecutionId: String): QueryExecutionState {
        val request = GetQueryExecutionRequest.builder()
            .queryExecutionId(queryExecutionId)
            .build()
        val response = athenaClient.getQueryExecution(request)
        return response.queryExecution().status().state()
    }

    override fun cancelQuery(queryExecutionId: String): Boolean {
        val request = StopQueryExecutionRequest.builder()
            .queryExecutionId(queryExecutionId)
            .build()
        return try {
            athenaClient.stopQueryExecution(request)
            // 쿼리 중지 요청 후, 실제로 취소되었는지 확인
            var attempts = 0
            val maxAttempts = 5
            val delayMillis = 1000L // 1초

            while (attempts < maxAttempts) {
                val status = getQueryStatus(queryExecutionId)
                if (status == QueryExecutionState.CANCELLED) {
                    println("Query $queryExecutionId successfully cancelled.")
                    return true
                } else if (status == QueryExecutionState.FAILED || status == QueryExecutionState.SUCCEEDED) {
                    println("Query $queryExecutionId is in an unexpected state after cancellation attempt: $status")
                    return false
                }
                Thread.sleep(delayMillis)
                attempts++
            }
            println("Query $queryExecutionId did not reach CANCELLED state within expected time.")
            false
        } catch (e: Exception) {
            println("Error cancelling query $queryExecutionId: ${e.message}")
            false
        }
    }
}