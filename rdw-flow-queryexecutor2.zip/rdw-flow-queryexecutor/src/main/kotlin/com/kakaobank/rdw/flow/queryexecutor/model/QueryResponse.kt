package com.kakaobank.rdw.flow.queryexecutor.model

import kotlinx.serialization.Serializable

@Serializable
data class QueryResponse(val queryExecutionId: String)