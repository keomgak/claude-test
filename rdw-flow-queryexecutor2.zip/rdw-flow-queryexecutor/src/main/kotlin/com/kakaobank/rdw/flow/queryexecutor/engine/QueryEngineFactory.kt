package com.kakaobank.rdw.flow.queryexecutor.engine

import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider

class QueryEngineFactory(private val credentialsProvider: AwsCredentialsProvider) {
    fun getEngine(engineType: String): QueryEngine {
        return when (engineType) {
            "Athena" -> AthenaQueryEngine(credentialsProvider)
            // Add other engine types here
            else -> throw IllegalArgumentException("Unsupported engine type: $engineType")
        }
    }
}