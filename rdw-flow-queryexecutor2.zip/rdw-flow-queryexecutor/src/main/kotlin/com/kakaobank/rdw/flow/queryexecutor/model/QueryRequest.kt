package com.kakaobank.rdw.flow.queryexecutor.model

import kotlinx.serialization.Serializable

@Serializable
data class QueryRequest(val query: String, val engineType: String)