package com.kakaobank.rdw.flow.queryexecutor

import com.kakaobank.rdw.flow.queryexecutor.plugins.configureRouting
import com.kakaobank.rdw.flow.queryexecutor.plugins.configureSerialization
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*

fun main() {
    embeddedServer(Netty, port = 8080, host = "0.0.0.0", module = Application::module)
        .start(wait = true)
}

fun Application.module() {
    configureSerialization()
    configureRouting()
}