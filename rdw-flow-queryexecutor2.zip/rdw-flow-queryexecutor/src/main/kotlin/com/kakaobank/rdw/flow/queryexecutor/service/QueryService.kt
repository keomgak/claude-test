package com.kakaobank.rdw.flow.queryexecutor.service

import com.kakaobank.rdw.flow.queryexecutor.engine.QueryEngineFactory
import com.kakaobank.rdw.flow.queryexecutor.updator.QueryStatusUpdator
import software.amazon.awssdk.services.athena.model.QueryExecutionState

class QueryService(
    private val queryEngineFactory: QueryEngineFactory,
    private val queryStatusUpdator: QueryStatusUpdator
) {

    suspend fun startQuery(query: String, engineType: String): String {
        val engine = queryEngineFactory.getEngine(engineType)
        val queryExecutionId = engine.startQuery(query)
        queryStatusUpdator.trackQueryStatus(queryExecutionId, engineType)
        return queryExecutionId
    }

    fun getQueryStatus(queryId: String, engineType: String): QueryExecutionState {
        val engine = queryEngineFactory.getEngine(engineType)
        return engine.getQueryStatus(queryId)
    }

    fun cancelQuery(queryId: String, engineType: String): Boolean {
        val engine = queryEngineFactory.getEngine(engineType)
        return engine.cancelQuery(queryId)
    }
}