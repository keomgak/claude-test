package com.kakaobank.rdw.flow.queryexecutor.engine

import software.amazon.awssdk.services.athena.model.QueryExecutionState

interface QueryEngine {
    fun startQuery(query: String): String
    fun getQueryStatus(queryExecutionId: String): QueryExecutionState
    fun cancelQuery(queryExecutionId: String): Boolean
}