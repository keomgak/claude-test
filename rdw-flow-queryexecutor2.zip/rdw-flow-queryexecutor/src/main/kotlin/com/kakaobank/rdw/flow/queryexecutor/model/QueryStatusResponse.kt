package com.kakaobank.rdw.flow.queryexecutor.model

import kotlinx.serialization.Serializable

@Serializable
data class QueryStatusResponse(val queryId: String, val status: String)