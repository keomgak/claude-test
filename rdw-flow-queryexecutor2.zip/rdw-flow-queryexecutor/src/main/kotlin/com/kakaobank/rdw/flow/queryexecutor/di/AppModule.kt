package com.kakaobank.rdw.flow.queryexecutor.di

import com.kakaobank.rdw.flow.queryexecutor.engine.QueryEngineFactory
import com.kakaobank.rdw.flow.queryexecutor.service.QueryService
import com.kakaobank.rdw.flow.queryexecutor.updator.QueryStatusUpdator
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider

object AppModule {
    private val credentialsProvider: ProfileCredentialsProvider by lazy {
        ProfileCredentialsProvider.builder()
            .profileName("my-roles-anywhere-profile") // 여기에 Roles Anywhere 프로필 이름을 입력하세요.
            .build()
    }
    private val queryEngineFactory by lazy { QueryEngineFactory(credentialsProvider) }
    private val queryStatusUpdator by lazy { QueryStatusUpdator(queryEngineFactory) }
    fun provideQueryService(): QueryService = QueryService(queryEngineFactory, queryStatusUpdator)
}