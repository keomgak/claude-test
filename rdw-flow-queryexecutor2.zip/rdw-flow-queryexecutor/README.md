# RDW Flow Query Executor (Ktor Application)

이 프로젝트는 Ktor 프레임워크를 사용하여 AWS Athena에 쿼리를 실행하고, 쿼리 상태를 조회하며, 쿼리를 취소하는 기능을 제공하는 애플리케이션입니다. 확장 가능한 아키텍처를 통해 향후 다른 쿼리 엔진(예: Spark, Presto)을 쉽게 통합할 수 있도록 설계되었습니다.

## 1. 주요 기능

*   **쿼리 실행 API**: 클라이언트로부터 쿼리 문자열과 엔진 타입(`engineType`)을 받아 해당 엔진에 쿼리 실행을 요청하고, 즉시 `queryExecutionId`를 반환합니다.
*   **쿼리 상태 조회 API**: `queryExecutionId`와 `engineType`을 받아 해당 쿼리의 현재 상태를 조회하여 반환합니다.
*   **쿼리 취소 API**: `queryExecutionId`와 `engineType`을 받아 해당 쿼리 실행을 중지하도록 요청하고, 취소 성공 여부를 반환합니다.
*   **확장 가능한 쿼리 엔진 아키텍처**: `QueryEngine` 인터페이스와 `QueryEngineFactory`를 통해 새로운 쿼리 엔진을 쉽게 추가할 수 있습니다. 현재는 Athena 엔진이 구현되어 있습니다.
*   **비동기 쿼리 상태 업데이트**: Kotlin Coroutines를 활용한 `QueryStatusUpdator`가 백그라운드에서 1분마다 쿼리 상태를 주기적으로 확인하고, 쿼리가 완료(성공/실패/취소)되면 추적을 중단합니다.
*   **AWS Roles Anywhere 인증 통합**: AWS SDK for Java v2의 `ProfileCredentialsProvider`를 사용하여 Roles Anywhere 방식으로 AWS에 인증할 수 있도록 설정되었습니다.

## 2. 프로젝트 구조

```
.
├── pom.xml
└── src
    └── main
        ├── kotlin
        │   └── com
        │       └── kakaobank
        │           └── rdw
        │               └── queryexecutor
        │                   ├── Application.kt
        │                   ├── di
        │                   │   └── AppModule.kt
        │                   ├── engine
        │                   │   ├── AthenaQueryEngine.kt
        │                   │   ├── QueryEngine.kt
        │                   │   └── QueryEngineFactory.kt
        │                   ├── model
        │                   │   ├── QueryCancelRequest.kt
        │                   │   ├── QueryCancelResponse.kt
        │                   │   ├── QueryRequest.kt
        │                   │   ├── QueryResponse.kt
        │                   │   ├── QueryStatusRequest.kt
        │                   │   └── QueryStatusResponse.kt
        │                   ├── plugins
        │                   │   ├── Routing.kt
        │                   │   └── Serialization.kt
        │                   ├── repository
        │                   │   └── AthenaRepository.kt
        │                   ├── service
        │                   │   └── QueryService.kt
        │                   └── updator
        │                       └── QueryStatusUpdator.kt
        └── resources
            ├── application.conf
            └── logback.xml
```

## 3. 설정 및 실행 방법

### 3.1. 필수 조건

*   Java 11 이상
*   Apache Maven
*   AWS CLI (Roles Anywhere 인증을 위해 필요)

### 3.2. AWS Roles Anywhere 설정

애플리케이션이 Roles Anywhere 방식으로 AWS에 인증하려면, `~/.aws/config` 파일에 Roles Anywhere 프로필을 구성해야 합니다.

1.  **AWS CLI 설치**: 아직 설치하지 않았다면, [AWS CLI 설치 가이드](https://docs.aws.amazon.com/ko_kr/cli/latest/userguide/getting-started-install.html)를 참조하여 설치합니다.
2.  **Roles Anywhere 프로필 구성**: `~/.aws/config` 파일을 열고 다음 내용을 추가합니다. `profileName`은 `AppModule.kt`에서 `ProfileCredentialsProvider.builder().profileName("...")`에 설정된 이름과 일치해야 합니다.

    ```ini
    [profile my-roles-anywhere-profile]
    credential_process = aws iam rolesanywhere create-session --profile-arn arn:aws:iam::123456789012:profile/my-profile --role-arn arn:aws:iam::123456789012:role/my-role --duration-seconds 900 --region ap-northeast-2 --output json
    ```
    *   `my-roles-anywhere-profile`: `AppModule.kt`에 설정된 프로필 이름입니다.
    *   `arn:aws:iam::123456789012:profile/my-profile`: 실제 Roles Anywhere 프로필 ARN으로 **반드시 변경**해야 합니다.
    *   `arn:aws:iam::123456789012:role/my-role`: 실제 IAM 역할 ARN으로 **반드시 변경**해야 합니다.
    *   `ap-northeast-2`: 사용하시는 AWS 리전으로 **반드시 변경**해야 합니다.

### 3.3. 프로젝트 빌드

프로젝트 루트 디렉토리에서 다음 Maven 명령어를 실행하여 의존성을 다운로드하고 프로젝트를 빌드합니다.

```bash
mvn clean install
```

### 3.4. 애플리케이션 실행

빌드가 성공하면 다음 명령어로 애플리케이션을 실행할 수 있습니다.

```bash
mvn exec:java
```

## 4. API 엔드포인트

애플리케이션이 실행되면 `http://localhost:8080`에서 다음 API 엔드포인트를 사용할 수 있습니다.

### 4.1. 쿼리 실행 (Start Query)

*   **URL**: `/query`
*   **Method**: `POST`
*   **Request Body (JSON)**:
    ```json
    {
      "query": "SELECT * FROM your_table LIMIT 10",
      "engineType": "Athena"
    }
    ```
    *   `query`: 실행할 쿼리 문자열.
    *   `engineType`: 사용할 쿼리 엔진 타입 (현재는 "Athena"만 지원).
*   **Response Body (JSON)**:
    ```json
    {
      "queryExecutionId": "your-query-execution-id"
    }
    ```
*   **예시 (cURL)**:
    ```bash
    curl -X POST http://localhost:8080/query \
    -H "Content-Type: application/json" \
    -d '{"query": "SELECT * FROM your_table LIMIT 10", "engineType": "Athena"}'
    ```

### 4.2. 쿼리 상태 조회 (Get Query Status)

*   **URL**: `/query/status`
*   **Method**: `POST`
*   **Request Body (JSON)**:
    ```json
    {
      "queryId": "your-query-execution-id",
      "engineType": "Athena"
    }
    ```
    *   `queryId`: 상태를 조회할 쿼리 실행 ID.
    *   `engineType`: 쿼리가 실행된 엔진 타입.
*   **Response Body (JSON)**:
    ```json
    {
      "queryId": "your-query-execution-id",
      "status": "SUCCEEDED" // 또는 RUNNING, FAILED, CANCELLED 등
    }
    ```
*   **예시 (cURL)**:
    ```bash
    curl -X POST http://localhost:8080/query/status \
    -H "Content-Type: application/json" \
    -d '{"queryId": "your-query-execution-id", "engineType": "Athena"}'
    ```

### 4.3. 쿼리 취소 (Cancel Query)

*   **URL**: `/query/cancel`
*   **Method**: `POST`
*   **Request Body (JSON)**:
    ```json
    {
      "queryId": "your-query-execution-id",
      "engineType": "Athena"
    }
    ```
    *   `queryId`: 취소할 쿼리 실행 ID.
    *   `engineType`: 쿼리가 실행된 엔진 타입.
*   **Response Body (JSON)**:
    ```json
    {
      "success": true // 또는 false
    }
    ```
*   **예시 (cURL)**:
    ```bash
    curl -X POST http://localhost:8080/query/cancel \
    -H "Content-Type: application/json" \
    -d '{"queryId": "your-query-execution-id", "engineType": "Athena"}'
    ```

## 5. 주요 파일 및 역할

*   `pom.xml`: Maven 빌드 설정 및 의존성 관리.
*   `Application.kt`: Ktor 애플리케이션의 메인 진입점.
*   `plugins/Routing.kt`: API 엔드포인트 정의 및 요청/응답 처리.
*   `plugins/Serialization.kt`: Kotlinx Serialization을 이용한 JSON 직렬화/역직렬화 설정.
*   `model/*.kt`: API 요청 및 응답을 위한 데이터 클래스 정의.
*   `engine/QueryEngine.kt`: 다양한 쿼리 엔진이 구현해야 할 공통 인터페이스.
*   `engine/AthenaQueryEngine.kt`: `QueryEngine` 인터페이스의 Athena 구현체.
*   `engine/QueryEngineFactory.kt`: `engineType`에 따라 적절한 `QueryEngine` 인스턴스를 제공하는 팩토리.
*   `service/QueryService.kt`: 비즈니스 로직을 포함하며, `QueryEngineFactory`와 `QueryStatusUpdator`를 사용하여 쿼리 관련 작업을 조율합니다.
*   `repository/AthenaRepository.kt`: (이전 `AthenaQueryExecutor`) Athena 쿼리 실행, 상태 조회, 취소와 같은 Athena 관련 작업을 수행합니다.
*   `updator/QueryStatusUpdator.kt`: 코루틴을 사용하여 백그라운드에서 쿼리 상태를 주기적으로 확인하고 완료 시 종료됩니다.
*   `di/AppModule.kt`: 애플리케이션의 의존성 주입을 설정합니다.
*   `resources/application.conf`: Ktor 애플리케이션의 포트 및 모듈 설정.
*   `resources/logback.xml`: 로깅 설정.

## 6. 다음 작업 시 고려 사항

*   **플레이스홀더 값 변경**: `AthenaQueryEngine.kt` 파일 내의 `your_database_name`, `s3://your-s3-bucket/query-results/` 및 `AppModule.kt` 내의 `my-roles-anywhere-profile`, Roles Anywhere ARN 값을 실제 환경에 맞게 **반드시 변경**해야 합니다.
*   **에러 핸들링 강화**: 현재는 기본적인 예외 처리만 되어 있습니다. 실제 운영 환경에서는 더 상세한 에러 로깅 및 사용자 친화적인 에러 응답 처리가 필요합니다.
*   **다른 쿼리 엔진 추가**: `QueryEngine` 인터페이스를 구현하여 Spark, Presto 등 다른 쿼리 엔진을 추가할 수 있습니다. `QueryEngineFactory`에 해당 엔진의 인스턴스 생성 로직을 추가하면 됩니다.
*   **테스트 코드 작성**: 현재 테스트 코드는 포함되어 있지 않습니다. 각 기능에 대한 단위 테스트 및 통합 테스트를 작성하여 코드의 안정성을 확보해야 합니다.
*   **보안 강화**: API 인증/인가, AWS 자격 증명 관리 등 보안 관련 부분을 강화해야 합니다.
*   **로깅 상세화**: `QueryStatusUpdator`의 로깅을 더 상세하게 (예: 쿼리 상태 변경 시점, 실패 원인 등) 기록하도록 개선할 수 있습니다.
