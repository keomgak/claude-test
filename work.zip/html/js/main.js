// DOM이 로드되면 실행
document.addEventListener('DOMContentLoaded', function() {
    // 차트 초기화
    initCharts();
    
    // 탭 기능 초기화
    initTabs();
    
    // 아코디언 기능 초기화
    initAccordion();
    
    // 슬라이더 기능 초기화
    initSlider();
});

// 차트 초기화 함수
function initCharts() {
    // 가격 차트 초기화
    const priceCtx = document.getElementById('priceChart').getContext('2d');
    const priceChart = new Chart(priceCtx, {
        type: 'line',
        data: {
            labels: ['2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [{
                label: '비트코인 가격 (USD, 로그 스케일)',
                data: [0.1, 1, 10, 1000, 300, 500, 1000, 20000, 3500, 7000, 29000, 69000, 16000, 42000, 73000, 105000],
                borderColor: '#4a148c',
                backgroundColor: 'rgba(74, 20, 140, 0.1)',
                borderWidth: 2,
                pointRadius: 3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    type: 'logarithmic',
                    title: {
                        display: true,
                        text: '가격 (USD, 로그 스케일)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '연도'
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `$${context.parsed.y.toLocaleString()}`;
                        }
                    }
                }
            }
        }
    });
    
    // 구글 트렌드 차트 초기화
    const trendsCtx = document.getElementById('trendsChart').getContext('2d');
    const trendsChart = new Chart(trendsCtx, {
        type: 'line',
        data: {
            labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [{
                label: '비트코인 가격 (USD, 천 단위)',
                data: [20, 3.5, 7, 29, 69, 16, 42, 73, 105],
                borderColor: '#4a148c',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y'
            }, {
                label: '구글 트렌드 검색 관심도 (0-100)',
                data: [100, 20, 10, 40, 75, 25, 35, 60, 45],
                borderColor: '#f44336',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    type: 'linear',
                    position: 'left',
                    title: {
                        display: true,
                        text: '가격 (천 USD)'
                    }
                },
                y1: {
                    type: 'linear',
                    position: 'right',
                    title: {
                        display: true,
                        text: '검색 관심도 (0-100)'
                    },
                    grid: {
                        drawOnChartArea: false
                    },
                    min: 0,
                    max: 100
                },
                x: {
                    title: {
                        display: true,
                        text: '연도'
                    }
                }
            }
        }
    });
    
    // M2 통화량 차트 초기화
    const m2Ctx = document.getElementById('m2Chart').getContext('2d');
    const m2Chart = new Chart(m2Ctx, {
        type: 'line',
        data: {
            labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [{
                label: '비트코인 가격 (USD, 천 단위)',
                data: [20, 3.5, 7, 29, 69, 16, 42, 73, 105],
                borderColor: '#4a148c',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y'
            }, {
                label: '글로벌 M2 통화량 (조 달러)',
                data: [75, 78, 80, 95, 105, 110, 112, 118, 125],
                borderColor: '#4caf50',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    type: 'linear',
                    position: 'left',
                    title: {
                        display: true,
                        text: '가격 (천 USD)'
                    }
                },
                y1: {
                    type: 'linear',
                    position: 'right',
                    title: {
                        display: true,
                        text: 'M2 통화량 (조 달러)'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '연도'
                    }
                }
            }
        }
    });
    
    // 인플레이션 차트 초기화
    const inflationCtx = document.getElementById('inflationChart').getContext('2d');
    const inflationChart = new Chart(inflationCtx, {
        type: 'line',
        data: {
            labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [{
                label: '비트코인 가격 (USD, 천 단위)',
                data: [20, 3.5, 7, 29, 69, 16, 42, 73, 105],
                borderColor: '#4a148c',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y'
            }, {
                label: '인플레이션 기대치 (%)',
                data: [1.8, 2.1, 1.5, 1.7, 4.5, 8.2, 5.3, 3.2, 2.8],
                borderColor: '#ff9800',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    type: 'linear',
                    position: 'left',
                    title: {
                        display: true,
                        text: '가격 (천 USD)'
                    }
                },
                y1: {
                    type: 'linear',
                    position: 'right',
                    title: {
                        display: true,
                        text: '인플레이션 기대치 (%)'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '연도'
                    }
                }
            }
        }
    });
    
    // 금리 차트 초기화
    const ratesCtx = document.getElementById('ratesChart').getContext('2d');
    const ratesChart = new Chart(ratesCtx, {
        type: 'line',
        data: {
            labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [{
                label: '비트코인 가격 (USD, 천 단위)',
                data: [20, 3.5, 7, 29, 69, 16, 42, 73, 105],
                borderColor: '#4a148c',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y'
            }, {
                label: '미국 기준금리 (%)',
                data: [1.5, 2.5, 1.75, 0.25, 0.25, 4.5, 5.5, 4.0, 3.0],
                borderColor: '#2196f3',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    type: 'linear',
                    position: 'left',
                    title: {
                        display: true,
                        text: '가격 (천 USD)'
                    }
                },
                y1: {
                    type: 'linear',
                    position: 'right',
                    title: {
                        display: true,
                        text: '기준금리 (%)'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '연도'
                    }
                }
            }
        }
    });
    
    // 달러 지수 차트 초기화
    const dxyCtx = document.getElementById('dxyChart').getContext('2d');
    const dxyChart = new Chart(dxyCtx, {
        type: 'line',
        data: {
            labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [{
                label: '비트코인 가격 (USD, 천 단위)',
                data: [20, 3.5, 7, 29, 69, 16, 42, 73, 105],
                borderColor: '#4a148c',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y'
            }, {
                label: '달러 지수 (DXY)',
                data: [92, 96, 97, 90, 94, 104, 103, 101, 97],
                borderColor: '#00bcd4',
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    type: 'linear',
                    position: 'left',
                    title: {
                        display: true,
                        text: '가격 (천 USD)'
                    }
                },
                y1: {
                    type: 'linear',
                    position: 'right',
                    title: {
                        display: true,
                        text: '달러 지수 (DXY)'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '연도'
                    }
                }
            }
        }
    });
    
    // 기술적 패턴 차트 초기화
    const technicalCtx = document.getElementById('technicalChart').getContext('2d');
    const technicalChart = new Chart(technicalCtx, {
        type: 'line',
        data: {
            labels: ['2022', '2023 Q1', '2023 Q2', '2023 Q3', '2023 Q4', '2024 Q1', '2024 Q2', '2025 Q1', '현재'],
            datasets: [{
                label: '비트코인 가격 (USD)',
                data: [16000, 28000, 31000, 25000, 42000, 73000, 65000, 109000, 105000],
                borderColor: '#4a148c',
                backgroundColor: 'rgba(74, 20, 140, 0.1)',
                borderWidth: 2,
                pointRadius: 3,
                fill: true
            }, {
                label: '로그 회귀 상한선',
                data: [100000, 120000, 140000, 160000, 180000, 200000, 220000, 240000, 250000],
                borderColor: '#f44336',
                borderDash: [5, 5],
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 1,
                pointRadius: 0
            }, {
                label: '로그 회귀 중앙선',
                data: [40000, 45000, 50000, 52000, 55000, 58000, 60000, 62000, 65000],
                borderColor: '#4caf50',
                borderDash: [5, 5],
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 1,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    title: {
                        display: true,
                        text: '가격 (USD)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '기간'
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `$${context.parsed.y.toLocaleString()}`;
                        }
                    }
                }
            }
        }
    });
    
    // 예측 차트 초기화
    const predictionCtx = document.getElementById('predictionChart').getContext('2d');
    const predictionChart = new Chart(predictionCtx, {
        type: 'line',
        data: {
            labels: ['현재', '2025년 6-7월', '2025년 8-9월', '2025년 10-11월', '2025년 12월-2026년 1월', '2026년 2-3월', '2026년 4-5월'],
            datasets: [{
                label: '기본 시나리오',
                data: [105000, 120000, 145000, 175000, 200000, 170000, 140000],
                borderColor: '#4caf50',
                backgroundColor: 'rgba(76, 175, 80, 0.1)',
                borderWidth: 2,
                fill: true
            }, {
                label: '낙관적 시나리오',
                data: [105000, 130000, 160000, 200000, 250000, 220000, 180000],
                borderColor: '#2196f3',
                borderDash: [5, 5],
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2
            }, {
                label: '비관적 시나리오',
                data: [105000, 100000, 110000, 120000, 100000, 90000, 80000],
                borderColor: '#f44336',
                borderDash: [5, 5],
                backgroundColor: 'rgba(0, 0, 0, 0)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    title: {
                        display: true,
                        text: '가격 (USD)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: '기간'
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `$${context.parsed.y.toLocaleString()}`;
                        }
                    }
                }
            }
        }
    });
}

// 탭 기능 초기화 함수
function initTabs() {
    const tabItems = document.querySelectorAll('.tab-item');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    tabItems.forEach(item => {
        item.addEventListener('click', function() {
            // 모든 탭 아이템에서 active 클래스 제거
            tabItems.forEach(tab => tab.classList.remove('active'));
            // 클릭한 탭 아이템에 active 클래스 추가
            this.classList.add('active');
            
            // 모든 탭 패널 숨기기
            tabPanes.forEach(pane => pane.classList.remove('active'));
            
            // 클릭한 탭에 해당하는 패널 표시
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
}

// 아코디언 기능 초기화 함수
function initAccordion() {
    const accordionHeaders = document.querySelectorAll('.accordion-header');
    
    accordionHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const accordionItem = this.parentElement;
            
            // 토글 아코디언 아이템 클래스
            accordionItem.classList.toggle('active');
        });
    });
}

// 슬라이더 기능 초기화 함수
function initSlider() {
    const slider = document.querySelector('.slider');
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.slider-prev');
    const nextBtn = document.querySelector('.slider-next');
    let slideIndex = 0;
    
    // 이전 슬라이드 버튼 클릭 이벤트
    prevBtn.addEventListener('click', function() {
        slideIndex = (slideIndex > 0) ? slideIndex - 1 : slides.length - 1;
        updateSlider();
    });
    
    // 다음 슬라이드 버튼 클릭 이벤트
    nextBtn.addEventListener('click', function() {
        slideIndex = (slideIndex < slides.length - 1) ? slideIndex + 1 : 0;
        updateSlider();
    });
    
    // 슬라이더 위치 업데이트 함수
    function updateSlider() {
        slider.style.transform = `translateX(-${slideIndex * 100}%)`;
    }
}
