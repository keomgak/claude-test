// Bitcoin Prediction Report - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize navigation toggle for mobile
    initMobileNav();
    
    // Initialize charts (if charts are present on the page)
    initCharts();
    
    // Initialize accordions
    initAccordions();
    
    // Initialize price calculator (if present)
    initPriceCalculator();
    
    // Initialize tooltips
    initTooltips();
});

// Mobile Navigation Toggle
function initMobileNav() {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('nav');
    
    if (navToggle) {
        navToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
            this.setAttribute('aria-expanded', nav.classList.contains('active'));
        });
    }
    
    // Close mobile nav when clicking on a nav item
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                nav.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    });
}

// Initialize Charts
function initCharts() {
    // Price History Chart
    const priceHistoryChart = document.getElementById('price-history-chart');
    if (priceHistoryChart) {
        new Chart(priceHistoryChart, {
            type: 'line',
            data: {
                labels: ['2022', '2023', '2024', '2025 (Current)', '2025 (Forecast)', '2026 (Forecast)'],
                datasets: [{
                    label: 'Bitcoin Price (USD)',
                    data: [16500, 42000, 100000, 105000, 180000, 150000],
                    borderColor: '#f7931a',
                    backgroundColor: 'rgba(247, 147, 26, 0.1)',
                    tension: 0.4,
                    pointRadius: 5,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: $${context.raw.toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Prediction Models Chart
    const predictionModelsChart = document.getElementById('prediction-models-chart');
    if (predictionModelsChart) {
        new Chart(predictionModelsChart, {
            type: 'bar',
            data: {
                labels: ['Stock-to-Flow', 'Logarithmic Regression', 'Elliott Wave', 'Fibonacci Extensions', 'MVRV Z-Score'],
                datasets: [{
                    label: 'Price Prediction for December 2025',
                    data: [210000, 200000, 180000, 195000, 170000],
                    backgroundColor: [
                        'rgba(247, 147, 26, 0.7)',
                        'rgba(61, 149, 213, 0.7)',
                        'rgba(111, 193, 88, 0.7)',
                        'rgba(217, 87, 87, 0.7)',
                        'rgba(147, 112, 219, 0.7)'
                    ],
                    borderColor: [
                        'rgba(247, 147, 26, 1)',
                        'rgba(61, 149, 213, 1)',
                        'rgba(111, 193, 88, 1)',
                        'rgba(217, 87, 87, 1)',
                        'rgba(147, 112, 219, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: $${context.raw.toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Scenario Analysis Chart
    const scenarioChart = document.getElementById('scenario-chart');
    if (scenarioChart) {
        new Chart(scenarioChart, {
            type: 'radar',
            data: {
                labels: ['Institutional Adoption', 'Regulatory Clarity', 'Macro Environment', 'Technical Development', 'Market Sentiment'],
                datasets: [
                    {
                        label: 'Bullish Scenario',
                        data: [9, 8, 7, 8, 9],
                        backgroundColor: 'rgba(111, 193, 88, 0.2)',
                        borderColor: 'rgba(111, 193, 88, 1)',
                        pointBackgroundColor: 'rgba(111, 193, 88, 1)',
                        pointBorderColor: '#fff',
                        pointHoverBackgroundColor: '#fff',
                        pointHoverBorderColor: 'rgba(111, 193, 88, 1)'
                    },
                    {
                        label: 'Base Scenario',
                        data: [6, 5, 6, 7, 6],
                        backgroundColor: 'rgba(61, 149, 213, 0.2)',
                        borderColor: 'rgba(61, 149, 213, 1)',
                        pointBackgroundColor: 'rgba(61, 149, 213, 1)',
                        pointBorderColor: '#fff',
                        pointHoverBackgroundColor: '#fff',
                        pointHoverBorderColor: 'rgba(61, 149, 213, 1)'
                    },
                    {
                        label: 'Bearish Scenario',
                        data: [3, 2, 4, 5, 3],
                        backgroundColor: 'rgba(217, 87, 87, 0.2)',
                        borderColor: 'rgba(217, 87, 87, 1)',
                        pointBackgroundColor: 'rgba(217, 87, 87, 1)',
                        pointBorderColor: '#fff',
                        pointHoverBackgroundColor: '#fff',
                        pointHoverBorderColor: 'rgba(217, 87, 87, 1)'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                elements: {
                    line: {
                        borderWidth: 3
                    }
                },
                scales: {
                    r: {
                        angleLines: {
                            display: true
                        },
                        suggestedMin: 0,
                        suggestedMax: 10
                    }
                }
            }
        });
    }
    
    // Timeline Price Prediction Chart
    const timelinePredictionChart = document.getElementById('timeline-prediction-chart');
    if (timelinePredictionChart) {
        new Chart(timelinePredictionChart, {
            type: 'line',
            data: {
                labels: [
                    'May 2025', 'Jun 2025', 'Jul 2025', 'Aug 2025', 'Sep 2025', 
                    'Oct 2025', 'Nov 2025', 'Dec 2025', 'Jan 2026', 'Feb 2026', 
                    'Mar 2026', 'Apr 2026', 'May 2026'
                ],
                datasets: [{
                    label: 'Base Scenario',
                    data: [105000, 115000, 125000, 135000, 145000, 160000, 175000, 185000, 200000, 190000, 165000, 145000, 135000],
                    borderColor: 'rgba(61, 149, 213, 1)',
                    backgroundColor: 'rgba(61, 149, 213, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Bullish Scenario',
                    data: [105000, 120000, 140000, 160000, 180000, 205000, 225000, 245000, 270000, 260000, 240000, 220000, 200000],
                    borderColor: 'rgba(111, 193, 88, 1)',
                    backgroundColor: 'rgba(111, 193, 88, 0.05)',
                    borderDash: [5, 5],
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Bearish Scenario',
                    data: [105000, 100000, 95000, 105000, 110000, 120000, 130000, 140000, 135000, 120000, 100000, 90000, 80000],
                    borderColor: 'rgba(217, 87, 87, 1)',
                    backgroundColor: 'rgba(217, 87, 87, 0.05)',
                    borderDash: [5, 5],
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: $${context.raw.toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Google Trends Correlation Chart
    const googleTrendsChart = document.getElementById('google-trends-chart');
    if (googleTrendsChart) {
        new Chart(googleTrendsChart, {
            type: 'line',
            data: {
                labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
                datasets: [
                    {
                        label: 'Bitcoin Price (Normalized)',
                        data: [20, 8, 9, 30, 69, 17, 42, 100, 105],
                        borderColor: '#f7931a',
                        backgroundColor: 'transparent',
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Google Trends Interest',
                        data: [100, 15, 10, 25, 82, 20, 35, 60, 55],
                        borderColor: '#3d95d5',
                        backgroundColor: 'transparent',
                        tension: 0.4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Bitcoin Price (Normalized)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Google Trends Interest'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        });
    }
}

// Initialize Accordions
function initAccordions() {
    const accordionHeaders = document.querySelectorAll('.accordion-header');
    
    accordionHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const accordionItem = this.parentElement;
            const accordionBody = this.nextElementSibling;
            
            // Toggle active class on accordion body
            accordionBody.classList.toggle('active');
            
            // Add or remove aria-expanded attribute for accessibility
            const isExpanded = accordionBody.classList.contains('active');
            this.setAttribute('aria-expanded', isExpanded);
        });
    });
}

// Initialize Price Calculator
function initPriceCalculator() {
    const calculator = document.getElementById('price-calculator');
    
    if (calculator) {
        const amountInput = document.getElementById('investment-amount');
        const scenarioSelect = document.getElementById('scenario-select');
        const calculateBtn = document.getElementById('calculate-btn');
        const resultElement = document.getElementById('calculator-result');
        
        calculateBtn.addEventListener('click', function() {
            // Get input values
            const amount = parseFloat(amountInput.value) || 0;
            const scenario = scenarioSelect.value;
            
            // Price targets based on scenario
            const priceTargets = {
                'bullish': 250000,
                'base': 190000,
                'bearish': 120000
            };
            
            // Current price (May 2025)
            const currentPrice = 105000;
            
            // Calculate potential return
            const targetPrice = priceTargets[scenario];
            const priceChange = (targetPrice - currentPrice) / currentPrice;
            const potentialValue = amount * (1 + priceChange);
            const profit = potentialValue - amount;
            
            // Display result
            resultElement.innerHTML = `
                <p>Based on the ${scenario} scenario (Price target: $${targetPrice.toLocaleString()}):</p>
                <p>Your $${amount.toLocaleString()} investment could be worth:</p>
                <p class="result-value">$${potentialValue.toLocaleString()}</p>
                <p>Potential profit: <span class="${profit >= 0 ? 'text-success' : 'text-danger'}">$${profit.toLocaleString()}</span> (${(priceChange * 100).toFixed(2)}%)</p>
            `;
        });
    }
}

// Initialize Tooltips
function initTooltips() {
    const tooltips = document.querySelectorAll('.tooltip');
    
    tooltips.forEach(tooltip => {
        tooltip.addEventListener('mouseenter', function() {
            const tooltipText = this.querySelector('.tooltip-text');
            
            // Ensure tooltip stays within viewport
            const rect = tooltipText.getBoundingClientRect();
            const viewportHeight = window.innerHeight;
            
            if (rect.top < 0) {
                tooltipText.style.bottom = 'auto';
                tooltipText.style.top = '125%';
            } else if (rect.bottom > viewportHeight) {
                tooltipText.style.top = 'auto';
                tooltipText.style.bottom = '125%';
            }
        });
    });
}

// Chart color theme for consistent styling
const chartColors = {
    primary: '#f7931a',
    secondary: '#3d95d5',
    success: '#6fc158',
    danger: '#d95757',
    purple: '#9370db',
    gray: '#4d4d4d'
};

// Handle chart time period selection
function updateChartTimePeriod(chartId, period) {
    // This function would update the selected chart's data based on the time period
    // For a real implementation, this would fetch different data sets
    
    // Get all period buttons for this chart
    const periodButtons = document.querySelectorAll(`[data-chart="${chartId}"] .chart-btn`);
    
    // Remove active class from all buttons
    periodButtons.forEach(btn => btn.classList.remove('active'));
    
    // Add active class to selected button
    document.querySelector(`[data-chart="${chartId}"][data-period="${period}"]`).classList.add('active');
    
    // Here you would update the chart data based on the selected period
    console.log(`Updating ${chartId} to ${period} period`);
}
