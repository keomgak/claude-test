// Bitcoin Prediction Report - Chart Configurations

// Bitcoin Price Prediction Timeline Chart Configuration
function createPredictionTimelineChart(ctx) {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: [
                'May 2025', 'Jun 2025', 'Jul 2025', 'Aug 2025', 'Sep 2025', 
                'Oct 2025', 'Nov 2025', 'Dec 2025', 'Jan 2026', 'Feb 2026', 
                'Mar 2026', 'Apr 2026', 'May 2026'
            ],
            datasets: [{
                label: 'Base Scenario',
                data: [105000, 115000, 125000, 135000, 145000, 160000, 175000, 185000, 200000, 190000, 165000, 145000, 135000],
                borderColor: 'rgba(61, 149, 213, 1)',
                backgroundColor: 'rgba(61, 149, 213, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'Bullish Scenario',
                data: [105000, 120000, 140000, 160000, 180000, 205000, 225000, 245000, 270000, 260000, 240000, 220000, 200000],
                borderColor: 'rgba(111, 193, 88, 1)',
                backgroundColor: 'rgba(111, 193, 88, 0.05)',
                borderDash: [5, 5],
                tension: 0.4,
                fill: true
            }, {
                label: 'Bearish Scenario',
                data: [105000, 100000, 95000, 105000, 110000, 120000, 130000, 140000, 135000, 120000, 100000, 90000, 80000],
                borderColor: 'rgba(217, 87, 87, 1)',
                backgroundColor: 'rgba(217, 87, 87, 0.05)',
                borderDash: [5, 5],
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: $${context.raw.toLocaleString()}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}

// Bitcoin Price History Chart Configuration
function createPriceHistoryChart(ctx) {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [{
                label: 'Bitcoin Price (USD)',
                data: [0, 0.09, 29.6, 13, 1163, 320, 300, 960, 20000, 3200, 7200, 29000, 69000, 16500, 42000, 100000, 105000],
                borderColor: '#f7931a',
                backgroundColor: 'rgba(247, 147, 26, 0.1)',
                tension: 0.4,
                pointRadius: 3,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: $${context.raw.toLocaleString()}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    type: 'logarithmic',
                    ticks: {
                        callback: function(value) {
                            if (value === 0) return '$0';
                            const ticks = [0.1, 1, 10, 100, 1000, 10000, 100000, 1000000];
                            if (ticks.includes(value)) {
                                return '$' + value.toLocaleString();
                            }
                            return '';
                        }
                    }
                }
            }
        }
    });
}

// Prediction Models Comparison Chart Configuration
function createPredictionModelsChart(ctx) {
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Stock-to-Flow', 'Logarithmic Regression', 'Elliott Wave', 'Fibonacci Extensions', 'MVRV Z-Score'],
            datasets: [{
                label: 'December 2025 Prediction',
                data: [210000, 200000, 180000, 195000, 170000],
                backgroundColor: [
                    'rgba(247, 147, 26, 0.7)',
                    'rgba(61, 149, 213, 0.7)',
                    'rgba(111, 193, 88, 0.7)',
                    'rgba(217, 87, 87, 0.7)',
                    'rgba(147, 112, 219, 0.7)'
                ],
                borderColor: [
                    'rgba(247, 147, 26, 1)',
                    'rgba(61, 149, 213, 1)',
                    'rgba(111, 193, 88, 1)',
                    'rgba(217, 87, 87, 1)',
                    'rgba(147, 112, 219, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: $${context.raw.toLocaleString()}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}

// Scenario Analysis Radar Chart Configuration
function createScenarioRadarChart(ctx) {
    return new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Institutional Adoption', 'Regulatory Clarity', 'Macro Environment', 'Technical Development', 'Market Sentiment'],
            datasets: [
                {
                    label: 'Bullish Scenario',
                    data: [9, 8, 7, 8, 9],
                    backgroundColor: 'rgba(111, 193, 88, 0.2)',
                    borderColor: 'rgba(111, 193, 88, 1)',
                    pointBackgroundColor: 'rgba(111, 193, 88, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(111, 193, 88, 1)'
                },
                {
                    label: 'Base Scenario',
                    data: [6, 5, 6, 7, 6],
                    backgroundColor: 'rgba(61, 149, 213, 0.2)',
                    borderColor: 'rgba(61, 149, 213, 1)',
                    pointBackgroundColor: 'rgba(61, 149, 213, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(61, 149, 213, 1)'
                },
                {
                    label: 'Bearish Scenario',
                    data: [3, 2, 4, 5, 3],
                    backgroundColor: 'rgba(217, 87, 87, 0.2)',
                    borderColor: 'rgba(217, 87, 87, 1)',
                    pointBackgroundColor: 'rgba(217, 87, 87, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(217, 87, 87, 1)'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            elements: {
                line: {
                    borderWidth: 3
                }
            },
            scales: {
                r: {
                    angleLines: {
                        display: true
                    },
                    suggestedMin: 0,
                    suggestedMax: 10
                }
            }
        }
    });
}

// Google Trends Correlation Chart Configuration
function createGoogleTrendsChart(ctx) {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [
                {
                    label: 'Bitcoin Price (Normalized)',
                    data: [20, 8, 9, 30, 69, 17, 42, 100, 105],
                    borderColor: '#f7931a',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    yAxisID: 'y'
                },
                {
                    label: 'Google Trends Interest',
                    data: [100, 15, 10, 25, 82, 20, 35, 60, 55],
                    borderColor: '#3d95d5',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            scales: {
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Bitcoin Price (Normalized)'
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Google Trends Interest'
                    },
                    grid: {
                        drawOnChartArea: false,
                    },
                }
            }
        }
    });
}

// Economic Indicators Correlation Chart Configuration
function createEconomicIndicatorsChart(ctx) {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
            datasets: [
                {
                    label: 'Bitcoin Price (Normalized)',
                    data: [20, 8, 9, 30, 69, 17, 42, 100, 105],
                    borderColor: '#f7931a',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    yAxisID: 'y'
                },
                {
                    label: 'M2 Money Supply Growth',
                    data: [5, 5.5, 6, 24, 13, 8, 2, 5, 7],
                    borderColor: '#6fc158',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    yAxisID: 'y1',
                    borderDash: [5, 5]
                },
                {
                    label: 'Interest Rates',
                    data: [1.25, 2.5, 1.75, 0.25, 0.25, 4.25, 5.25, 4.5, 3.75],
                    borderColor: '#9370db',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    yAxisID: 'y1',
                    borderDash: [2, 2]
                }
            ]
        },
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            scales: {
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Bitcoin Price (Normalized)'
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Economic Indicators'
                    },
                    grid: {
                        drawOnChartArea: false,
                    },
                }
            }
        }
    });
}

// Price Prediction Range Chart (Confidence Intervals)
function createPredictionRangeChart(ctx) {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['May 2025', 'Jun 2025', 'Jul 2025', 'Aug 2025', 'Sep 2025', 'Oct 2025', 'Nov 2025', 'Dec 2025', 'Jan 2026'],
            datasets: [
                {
                    label: 'Expected Price',
                    data: [105000, 115000, 125000, 135000, 145000, 160000, 175000, 185000, 190000],
                    borderColor: '#f7931a',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    borderWidth: 2
                },
                {
                    label: '70% Confidence Interval',
                    data: [105000, 105000, 105000, 105000, 105000, 105000, 105000, 105000, 105000],
                    borderColor: 'transparent',
                    backgroundColor: 'rgba(61, 149, 213, 0.2)',
                    tension: 0.4,
                    fill: 0,
                    pointRadius: 0
                },
                {
                    label: '70% Confidence Interval Upper',
                    data: [105000, 125000, 145000, 165000, 180000, 200000, 220000, 230000, 240000],
                    borderColor: 'transparent',
                    tension: 0.4,
                    fill: '-1',
                    pointRadius: 0
                },
                {
                    label: '95% Confidence Interval',
                    data: [105000, 95000, 95000, 95000, 95000, 95000, 95000, 95000, 95000],
                    borderColor: 'transparent',
                    backgroundColor: 'rgba(247, 147, 26, 0.1)',
                    tension: 0.4,
                    fill: 0,
                    pointRadius: 0
                },
                {
                    label: '95% Confidence Interval Upper',
                    data: [105000, 135000, 160000, 180000, 200000, 230000, 250000, 270000, 290000],
                    borderColor: 'transparent',
                    tension: 0.4,
                    fill: '-1',
                    pointRadius: 0
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        filter: function(item) {
                            // Only show the expected price in the legend
                            return item.text === 'Expected Price';
                        }
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            const label = context.dataset.label;
                            const value = context.raw;
                            if (label === 'Expected Price') {
                                return `${label}: $${value.toLocaleString()}`;
                            }
                            return null;
                        },
                        footer: function(tooltipItems) {
                            const index = tooltipItems[0].dataIndex;
                            const values = tooltipItems[0].chart.data.datasets;
                            
                            const lower70 = values[1].data[index];
                            const upper70 = values[2].data[index];
                            const lower95 = values[3].data[index];
                            const upper95 = values[4].data[index];
                            
                            return [
                                `70% CI: $${lower70.toLocaleString()} - $${upper70.toLocaleString()}`,
                                `95% CI: $${lower95.toLocaleString()} - $${upper95.toLocaleString()}`
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}

// Halving Cycle Analysis Chart
function createHalvingCycleChart(ctx) {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['1st Cycle (2012)', '2nd Cycle (2016)', '3rd Cycle (2020)', '4th Cycle (2024)', '5th Cycle (Estimated 2028)'],
            datasets: [
                {
                    label: 'Peak Price After Halving',
                    data: [1150, 20000, 69000, 190000, 400000],
                    borderColor: '#f7931a',
                    backgroundColor: 'rgba(247, 147, 26, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Months to Peak',
                    data: [12, 17, 18, 12, 14],
                    borderColor: '#3d95d5',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    yAxisID: 'y1',
                    borderDash: [5, 5]
                },
                {
                    label: 'ROI Multiple',
                    data: [100, 20, 7, 4, 2.5],
                    borderColor: '#6fc158',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    yAxisID: 'y2',
                    borderDash: [2, 2]
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            const label = context.dataset.label;
                            const value = context.raw;
                            if (label === 'Peak Price After Halving') {
                                return `${label}: $${value.toLocaleString()}`;
                            } else if (label === 'Months to Peak') {
                                return `${label}: ${value} months`;
                            } else if (label === 'ROI Multiple') {
                                return `${label}: ${value}x`;
                            }
                            return `${label}: ${value}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    type: 'logarithmic',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Price (USD)'
                    },
                    ticks: {
                        callback: function(value) {
                            if ([1000, 10000, 100000, 1000000].includes(value)) {
                                return '$' + value.toLocaleString();
                            }
                            return '';
                        }
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Months to Peak'
                    },
                    grid: {
                        drawOnChartArea: false,
                    },
                    min: 0,
                    max: 24
                },
                y2: {
                    type: 'linear',
                    display: false,
                    min: 0,
                    max: 100
                }
            }
        }
    });
}

// Initialize all charts when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Create charts if the elements exist
    const predictionTimelineEl = document.getElementById('timeline-prediction-chart');
    if (predictionTimelineEl) {
        createPredictionTimelineChart(predictionTimelineEl);
    }
    
    const priceHistoryEl = document.getElementById('price-history-chart');
    if (priceHistoryEl) {
        createPriceHistoryChart(priceHistoryEl);
    }
    
    const predictionModelsEl = document.getElementById('prediction-models-chart');
    if (predictionModelsEl) {
        createPredictionModelsChart(predictionModelsEl);
    }
    
    const scenarioRadarEl = document.getElementById('scenario-chart');
    if (scenarioRadarEl) {
        createScenarioRadarChart(scenarioRadarEl);
    }
    
    const googleTrendsEl = document.getElementById('google-trends-chart');
    if (googleTrendsEl) {
        createGoogleTrendsChart(googleTrendsEl);
    }
    
    const economicIndicatorsEl = document.getElementById('economic-indicators-chart');
    if (economicIndicatorsEl) {
        createEconomicIndicatorsChart(economicIndicatorsEl);
    }
    
    const predictionRangeEl = document.getElementById('prediction-range-chart');
    if (predictionRangeEl) {
        createPredictionRangeChart(predictionRangeEl);
    }
    
    const halvingCycleEl = document.getElementById('halving-cycle-chart');
    if (halvingCycleEl) {
        createHalvingCycleChart(halvingCycleEl);
    }
});
